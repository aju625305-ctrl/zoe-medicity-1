import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Search, c as HeartPulse, d as ChartColumn, f as CalendarPlus, i as ShieldCheck, l as Droplets, m as Baby, o as LogOut, p as Bone, r as Stethoscope, s as LayoutDashboard, t as Users, u as ClipboardList } from "../_libs/lucide-react.mjs";
import { a as Cell, i as Bar, n as YAxis, o as ResponsiveContainer, r as XAxis, s as Tooltip, t as BarChart } from "../_libs/recharts+[...].mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DkBFWIOk.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Mark({ className = "size-11" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 64 64",
		className,
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "22",
				y: "4",
				width: "20",
				height: "56",
				rx: "8",
				fill: "var(--color-blue)"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "4",
				y: "22",
				width: "56",
				height: "20",
				rx: "8",
				fill: "var(--color-blue)"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "36",
				y: "22",
				width: "24",
				height: "20",
				rx: "6",
				fill: "var(--color-leaf)"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M27 30.2c1.5-2.7 5.4-2.5 5.8.8.4-3.3 4.4-3.5 5.8-.8 1.6 2.9-.4 5.8-5.8 9.1-5.4-3.3-7.4-6.2-5.8-9.1Z",
				fill: "white"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M46.2 28.6c1.6 1.2 2.2 2.6 2.2 4.2 0 .4-.4.8-.8.6-1.5-.6-2.6-.2-3.6.8-.3.3-.8.1-.8-.3 0-2.2 1.2-4.2 3-5.3Z",
				fill: "white"
			})
		]
	});
}
function Wordmark({ light = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "flex items-center gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "min-w-0",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: `block text-lg font-bold leading-none ${light ? "text-white" : "text-ink"}`,
				children: "Zoe Medicity"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: `mt-1 block text-xs font-medium tracking-wide ${light ? "text-white/80" : "text-blue"}`,
				children: "Care Beyond Limits"
			})]
		})]
	});
}
var DEPARTMENTS = [
	"General Medicine",
	"Cardiology",
	"Dermatology",
	"Orthopaedics",
	"Paediatrics"
];
var DOCTORS = {
	"General Medicine": ["Dr. Meera Iyer", "Dr. Arun Shah"],
	Cardiology: ["Dr. Leela Nair", "Dr. Vikram Bose"],
	Dermatology: ["Dr. Sana Qureshi", "Dr. Imran Lal"],
	Orthopaedics: ["Dr. Rohan Desai", "Dr. Kavya Menon"],
	Paediatrics: ["Dr. Anika Rao", "Dr. Farhan Qadri"]
};
var PILLARS = [
	{
		title: "Better Care",
		detail: "Every visit is written down and easy to find."
	},
	{
		title: "A Healthier Tomorrow",
		detail: "The ward list stays ready for the next shift."
	},
	{
		title: "Trusted Always",
		detail: "Records stay on this desk, on this device."
	}
];
function generateAppointmentId(number) {
	return "APT" + String(number).padStart(3, "0");
}
function calculateFee(fee = 500, discount = 0) {
	return fee - discount;
}
function searchPatient(appointments, patientName) {
	const query = patientName.trim().toLowerCase();
	if (!query) return [];
	return appointments.filter((appointment) => appointment.patient.toLowerCase() === query);
}
function countAppointments(appointments) {
	return appointments.length;
}
function formatDisplayDate(iso) {
	const [year, month, day] = iso.split("-");
	if (!year || !month || !day) return iso;
	return `${day}-${month}-${year}`;
}
function formatPhone(phone) {
	if (phone.length !== 10) return phone;
	return `${phone.slice(0, 5)} ${phone.slice(5)}`;
}
function formatRupees(amount) {
	return `₹${amount.toLocaleString("en-IN")}`;
}
function todayIso(now = /* @__PURE__ */ new Date()) {
	return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}`;
}
function shiftIso(days, now = /* @__PURE__ */ new Date()) {
	const next = new Date(now);
	next.setDate(next.getDate() + days);
	return todayIso(next);
}
function greeting(now = /* @__PURE__ */ new Date()) {
	const hour = now.getHours();
	if (hour < 12) return "Good morning";
	if (hour < 17) return "Good afternoon";
	return "Good evening";
}
function createSeed(now = /* @__PURE__ */ new Date()) {
	return [
		{
			id: "APT001",
			patient: "Aisha Rahman",
			age: 34,
			phone: "9845011122",
			department: "Cardiology",
			doctor: "Dr. Leela Nair",
			date: todayIso(now),
			fee: 500,
			sample: true
		},
		{
			id: "APT002",
			patient: "Rohan Deshmukh",
			age: 8,
			phone: "9810099344",
			department: "Paediatrics",
			doctor: "Dr. Anika Rao",
			date: todayIso(now),
			fee: 450,
			sample: true
		},
		{
			id: "APT003",
			patient: "Meera Krishnan",
			age: 57,
			phone: "9900123488",
			department: "Orthopaedics",
			doctor: "Dr. Rohan Desai",
			date: shiftIso(1, now),
			fee: 700,
			sample: true
		},
		{
			id: "APT004",
			patient: "Imran Qureshi",
			age: 41,
			phone: "9765432109",
			department: "Dermatology",
			doctor: "Dr. Sana Qureshi",
			date: shiftIso(1, now),
			fee: 500,
			sample: true
		},
		{
			id: "APT005",
			patient: "Aisha Rahman",
			age: 34,
			phone: "9845011122",
			department: "General Medicine",
			doctor: "Dr. Meera Iyer",
			date: shiftIso(3, now),
			fee: 400,
			sample: true
		}
	];
}
var useDesk = create()(persist((set, get) => ({
	session: null,
	appointments: createSeed(),
	nextNumber: 6,
	signIn: (session) => set({ session }),
	signOut: () => set({ session: null }),
	book: (draft) => {
		const number = get().nextNumber;
		const appointment = {
			id: generateAppointmentId(number),
			patient: draft.patient.trim(),
			age: draft.age,
			phone: draft.phone,
			department: draft.department,
			doctor: draft.doctor.trim(),
			date: draft.date,
			fee: calculateFee(draft.baseFee, draft.discount)
		};
		set({
			appointments: [...get().appointments, appointment],
			nextNumber: number + 1
		});
		return appointment;
	},
	cancel: (id) => {
		const current = get().appointments;
		const next = current.filter((appointment) => appointment.id !== id);
		if (next.length === current.length) return false;
		set({ appointments: next });
		return true;
	},
	clearSamples: () => set({ appointments: get().appointments.filter((appointment) => !appointment.sample) })
}), {
	name: "zoe-medicity-desk",
	partialize: (state) => ({
		session: state.session,
		appointments: state.appointments,
		nextNumber: state.nextNumber
	})
}));
var NAV = [
	{
		id: "desk",
		label: "Desk",
		icon: LayoutDashboard
	},
	{
		id: "book",
		label: "Book",
		icon: CalendarPlus
	},
	{
		id: "registry",
		label: "Registry",
		icon: ClipboardList
	},
	{
		id: "insights",
		label: "Insights",
		icon: ChartColumn
	}
];
var DEPT_ICON = {
	"General Medicine": Stethoscope,
	Cardiology: HeartPulse,
	Dermatology: Droplets,
	Orthopaedics: Bone,
	Paediatrics: Baby
};
var SHORT_DEPT = {
	"General Medicine": "General",
	Cardiology: "Cardio",
	Dermatology: "Derm",
	Orthopaedics: "Ortho",
	Paediatrics: "Paeds"
};
var PILLAR_ICONS$1 = [
	HeartPulse,
	Users,
	ShieldCheck
];
var EMPTY_FORM = {
	department: "",
	patient: "",
	age: "",
	phone: "",
	doctor: "",
	date: "",
	baseFee: "500",
	discount: "0"
};
function fieldClass(invalid) {
	return "mt-2 w-full rounded-md border bg-mist px-3 py-3 text-base font-medium text-ink placeholder:font-normal placeholder:text-muted " + (invalid ? "border-navy" : "border-line");
}
function Desk() {
	const session = useDesk((state) => state.session);
	const signOut = useDesk((state) => state.signOut);
	const [tab, setTab] = (0, import_react.useState)("desk");
	if (!session) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-sky lg:grid lg:grid-cols-[17.5rem_minmax(0,1fr)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: "hidden bg-navy text-white lg:flex lg:min-h-dvh lg:flex-col lg:px-5 lg:py-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wordmark, { light: true }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "mt-8 flex flex-col gap-1",
					"aria-label": "Desk",
					children: NAV.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavButton, {
						item,
						active: tab === item.id,
						onSelect: setTab
					}, item.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-auto",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "space-y-3 border-t border-white/15 pt-5",
						children: PILLARS.map((pillar, index) => {
							const Icon = PILLAR_ICONS$1[index];
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
									className: "mt-0.5 size-4 shrink-0 text-leaf",
									"aria-hidden": "true"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-sm font-semibold",
									children: pillar.title
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-xs leading-snug text-white/70",
									children: pillar.detail
								})] })]
							}, pillar.title);
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-5 rounded-md bg-white/10 px-3 py-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm font-semibold",
								children: session.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-white/70",
								children: session.role
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: signOut,
								className: "mt-3 flex min-h-11 w-full items-center justify-center gap-2 rounded-md border border-white/25 text-sm font-semibold",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, {
									className: "size-4",
									"aria-hidden": "true"
								}), "Sign out"]
							})
						]
					})]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "sticky top-0 z-20 flex items-center justify-between gap-3 border-b border-line bg-surface px-4 py-3 lg:hidden",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wordmark, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: signOut,
						className: "inline-flex min-h-11 items-center gap-1 rounded-md px-2 text-sm font-semibold text-navy",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, {
							className: "size-4",
							"aria-hidden": "true"
						}), "Out"]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
					className: "mx-auto w-full max-w-5xl px-4 py-5 pb-28 lg:px-8 lg:py-8 lg:pb-10",
					children: [
						tab === "desk" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DeskHome, { onBook: () => setTab("book") }) : null,
						tab === "book" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookPanel, {}) : null,
						tab === "registry" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Registry, {}) : null,
						tab === "insights" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Insights, {}) : null
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "fixed inset-x-0 bottom-0 z-20 grid grid-cols-4 border-t border-line bg-surface px-2 py-1 lg:hidden",
					"aria-label": "Desk",
					children: NAV.map((item) => {
						const Icon = item.icon;
						const active = tab === item.id;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setTab(item.id),
							className: active ? "flex min-h-14 flex-col items-center justify-center gap-1 text-xs font-semibold text-blue" : "flex min-h-14 flex-col items-center justify-center gap-1 text-xs font-medium text-muted",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
								className: "size-5",
								"aria-hidden": "true"
							}), item.label]
						}, item.id);
					})
				})
			]
		})]
	});
}
function NavButton({ item, active, onSelect }) {
	const Icon = item.icon;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick: () => onSelect(item.id),
		className: active ? "flex min-h-11 items-center gap-3 rounded-md bg-white/20 px-3 text-left text-sm font-semibold text-white" : "flex min-h-11 items-center gap-3 rounded-md px-3 text-left text-sm font-medium text-white/75 hover:bg-white/10 hover:text-white",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
			className: "size-4",
			"aria-hidden": "true"
		}), item.id === "book" ? "Book appointment" : item.label]
	});
}
function SampleNote() {
	const appointments = useDesk((state) => state.appointments);
	const clearSamples = useDesk((state) => state.clearSamples);
	if (!appointments.some((appointment) => appointment.sample)) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-5 flex flex-col gap-3 rounded-md border border-line bg-surface px-4 py-3 sm:flex-row sm:items-center sm:justify-between",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted",
			children: "A sample ward list is on the desk so search, cancel, and statistics have something to show."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			onClick: clearSamples,
			className: "min-h-11 shrink-0 rounded-md border border-line px-3 text-sm font-semibold text-ink",
			children: "Clear samples"
		})]
	});
}
function DeskHome({ onBook }) {
	const session = useDesk((state) => state.session);
	const appointments = useDesk((state) => state.appointments);
	const today = todayIso();
	const todays = appointments.filter((appointment) => appointment.date === today);
	const upcoming = [...appointments].filter((appointment) => appointment.date >= today).sort((a, b) => a.date.localeCompare(b.date) || a.patient.localeCompare(b.patient));
	const collected = appointments.reduce((sum, appointment) => sum + appointment.fee, 0);
	const first = session?.name.split(" ")[0] ?? "there";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rise",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SampleNote, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-lg bg-navy px-5 py-6 text-white sm:px-7",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm font-medium text-white/75",
						children: [
							session?.role,
							" desk · ",
							formatDisplayDate(today)
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
						className: "mt-2 text-3xl font-bold tracking-tight sm:text-4xl",
						children: [
							greeting(),
							", ",
							first,
							"."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 max-w-xl text-sm text-white/80",
						children: "Zoe Medicity reception. Book a visit, find a patient, or close a slip that is no longer needed."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: onBook,
						className: "mt-5 inline-flex min-h-11 items-center gap-2 rounded-md bg-white px-4 text-sm font-semibold text-navy",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarPlus, {
							className: "size-4",
							"aria-hidden": "true"
						}), "Book appointment"]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "mt-4 grid grid-cols-3 gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "On the books",
						value: String(countAppointments(appointments))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Today",
						value: String(todays.length)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Fees booked",
						value: formatRupees(collected)
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-lg font-bold text-ink",
					children: "Today’s list"
				}), todays.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 rounded-md border border-dashed border-line bg-surface px-4 py-6 text-sm text-muted",
					children: "No one is booked for today. The next visits are below, or book a new one."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 space-y-3",
					children: todays.map((appointment) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppointmentCard, { appointment }) }, appointment.id))
				})]
			}),
			upcoming.length > todays.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-lg font-bold text-ink",
					children: "Coming up"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 space-y-3",
					children: upcoming.filter((appointment) => appointment.date !== today).slice(0, 4).map((appointment) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppointmentCard, { appointment }) }, appointment.id))
				})]
			}) : null
		]
	});
}
function Stat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-md border border-line bg-surface px-3 py-3 sm:px-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "text-xs font-medium text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: "mt-1 text-lg font-bold tabular-nums text-ink sm:text-2xl",
			children: value
		})]
	});
}
function AppointmentCard({ appointment }) {
	const cancel = useDesk((state) => state.cancel);
	const [confirming, setConfirming] = (0, import_react.useState)(false);
	const Icon = DEPT_ICON[appointment.department];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "rounded-md border border-line bg-surface px-4 py-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-semibold tracking-wide text-blue tabular-nums",
							children: appointment.id
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mt-1 truncate text-base font-bold text-ink",
							children: appointment.patient
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-muted",
							children: [
								appointment.age,
								" yrs · ",
								formatPhone(appointment.phone)
							]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "shrink-0 text-sm font-bold tabular-nums text-ink",
					children: formatRupees(appointment.fee)
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex flex-wrap items-center gap-2 text-sm text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "inline-flex items-center gap-1 rounded-md bg-sky px-2 py-1 font-semibold text-blue",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
							className: "size-3.5",
							"aria-hidden": "true"
						}), appointment.department]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: appointment.doctor }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "tabular-nums",
						children: formatDisplayDate(appointment.date)
					}),
					appointment.sample ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs",
						children: "Sample"
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3",
				children: confirming ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => cancel(appointment.id),
						className: "min-h-11 rounded-md bg-navy px-3 text-sm font-semibold text-white",
						children: "Confirm cancel"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setConfirming(false),
						className: "min-h-11 rounded-md border border-line px-3 text-sm font-semibold text-ink",
						children: "Keep"
					})]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setConfirming(true),
					className: "min-h-11 rounded-md px-1 text-sm font-semibold text-navy",
					children: "Cancel appointment"
				})
			})
		]
	});
}
function BookPanel() {
	const book = useDesk((state) => state.book);
	const nextNumber = useDesk((state) => state.nextNumber);
	const [form, setForm] = (0, import_react.useState)(EMPTY_FORM);
	const [errors, setErrors] = (0, import_react.useState)({});
	const [slip, setSlip] = (0, import_react.useState)(null);
	const base = Number(form.baseFee);
	const discount = Number(form.discount);
	const preview = form.baseFee.trim() !== "" && Number.isInteger(base) && Number.isInteger(discount) && base >= 0 && discount >= 0 && discount <= base ? calculateFee(base, discount) : null;
	const doctors = form.department ? DOCTORS[form.department] : [];
	function update(key, value) {
		setForm((current) => {
			const next = {
				...current,
				[key]: value
			};
			if (key === "department" && current.department && current.department !== value) {
				if (DOCTORS[current.department].includes(current.doctor)) next.doctor = "";
			}
			return next;
		});
		setErrors((current) => {
			if (!current[key]) return current;
			const next = { ...current };
			delete next[key];
			return next;
		});
	}
	function submit(event) {
		event.preventDefault();
		const nextErrors = {};
		const patient = form.patient.trim();
		const doctor = form.doctor.trim();
		const phone = form.phone.replace(/\s+/g, "");
		const age = Number(form.age);
		const fee = Number(form.baseFee);
		const off = Number(form.discount);
		if (!form.department) nextErrors.department = "Choose a department.";
		if (!patient) nextErrors.patient = "Patient name cannot be empty.";
		if (!Number.isInteger(age) || age < 1) nextErrors.age = "Enter a whole number of years, at least 1.";
		if (!/^\d{10}$/.test(phone)) nextErrors.phone = "Enter a valid 10-digit phone number.";
		if (!doctor) nextErrors.doctor = "Doctor and date cannot be empty.";
		if (!form.date) nextErrors.date = "Doctor and date cannot be empty.";
		if (form.baseFee.trim() === "" || !Number.isInteger(fee) || fee < 0) nextErrors.baseFee = "Enter a valid fee.";
		if (form.discount.trim() === "" || !Number.isInteger(off) || off < 0) nextErrors.discount = "Enter a valid discount.";
		else if (Number.isInteger(fee) && off > fee) nextErrors.discount = "Discount cannot be more than the fee.";
		if (Object.keys(nextErrors).length || !form.department) {
			setErrors(nextErrors);
			return;
		}
		const draft = {
			patient,
			age,
			phone,
			department: form.department,
			doctor,
			date: form.date,
			baseFee: fee,
			discount: off
		};
		const appointment = book(draft);
		setSlip({
			appointment,
			base: fee,
			discount: off
		});
		setForm(EMPTY_FORM);
		setErrors({});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rise",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-3xl font-bold tracking-tight text-ink",
				children: "Book appointment"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-sm text-muted",
				children: [
					"Next slip ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-semibold tabular-nums text-ink",
						children: generateAppointmentId(nextNumber)
					}),
					". Standard consult is ",
					formatRupees(500),
					" before any discount."
				]
			}),
			slip ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5 rounded-md border border-leaf bg-leaf-soft px-4 py-4",
				role: "status",
				"aria-live": "polite",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-semibold text-leaf",
						children: "Appointment booked successfully"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-1 text-xl font-bold text-ink",
						children: slip.appointment.patient
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "mt-3 grid gap-2 text-sm sm:grid-cols-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlipRow, {
								label: "Appointment ID",
								value: slip.appointment.id
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlipRow, {
								label: "Age",
								value: `${slip.appointment.age}`
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlipRow, {
								label: "Phone",
								value: formatPhone(slip.appointment.phone)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlipRow, {
								label: "Department",
								value: slip.appointment.department
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlipRow, {
								label: "Doctor",
								value: slip.appointment.doctor
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlipRow, {
								label: "Date",
								value: formatDisplayDate(slip.appointment.date)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlipRow, {
								label: "Fee",
								value: slip.discount > 0 ? `${formatRupees(slip.base)} − ${formatRupees(slip.discount)} = ${formatRupees(slip.appointment.fee)}` : formatRupees(slip.appointment.fee)
							})
						]
					})
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: submit,
				className: "mt-5 grid gap-6 lg:grid-cols-[minmax(0,1fr)_16rem]",
				noValidate: true,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
								className: "text-sm font-semibold text-ink",
								children: "Department"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-2 grid gap-2 sm:grid-cols-2",
								children: DEPARTMENTS.map((department, index) => {
									const Icon = DEPT_ICON[department];
									const selected = form.department === department;
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										"aria-pressed": selected,
										onClick: () => update("department", department),
										className: selected ? "flex min-h-12 items-center gap-3 rounded-md border border-blue bg-sky px-3 text-left text-sm font-semibold text-navy" : "flex min-h-12 items-center gap-3 rounded-md border border-line bg-surface px-3 text-left text-sm font-semibold text-ink",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
											className: "size-4 shrink-0 text-blue",
											"aria-hidden": "true"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "mr-2 text-xs font-medium text-muted",
											children: index + 1
										}), department] })]
									}, department);
								})
							}),
							errors.department ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldError, { message: errors.department }) : null
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-4 sm:grid-cols-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "block text-sm font-semibold text-ink",
									htmlFor: "patient-name",
									children: [
										"Patient name",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											id: "patient-name",
											value: form.patient,
											onChange: (event) => update("patient", event.target.value),
											autoComplete: "name",
											className: fieldClass(Boolean(errors.patient))
										}),
										errors.patient ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldError, { message: errors.patient }) : null
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "block text-sm font-semibold text-ink",
									htmlFor: "patient-age",
									children: [
										"Age",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											id: "patient-age",
											inputMode: "numeric",
											value: form.age,
											onChange: (event) => update("age", event.target.value.replace(/[^\d]/g, "")),
											className: fieldClass(Boolean(errors.age))
										}),
										errors.age ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldError, { message: errors.age }) : null
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "block text-sm font-semibold text-ink",
									htmlFor: "patient-phone",
									children: [
										"Phone",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											id: "patient-phone",
											inputMode: "numeric",
											autoComplete: "tel",
											value: form.phone,
											onChange: (event) => update("phone", event.target.value.replace(/[^\d]/g, "").slice(0, 10)),
											placeholder: "10 digits",
											className: fieldClass(Boolean(errors.phone))
										}),
										errors.phone ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldError, { message: errors.phone }) : null
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "block text-sm font-semibold text-ink",
									htmlFor: "doctor-name",
									children: [
										"Doctor",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											id: "doctor-name",
											list: "doctor-suggestions",
											value: form.doctor,
											onChange: (event) => update("doctor", event.target.value),
											placeholder: form.department ? "Pick a consultant or type a name" : "Choose a department first",
											className: fieldClass(Boolean(errors.doctor))
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("datalist", {
											id: "doctor-suggestions",
											children: doctors.map((doctor) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { value: doctor }, doctor))
										}),
										errors.doctor ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldError, { message: errors.doctor }) : null
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "block text-sm font-semibold text-ink",
									htmlFor: "visit-date",
									children: [
										"Date",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											id: "visit-date",
											type: "date",
											value: form.date,
											onChange: (event) => update("date", event.target.value),
											className: fieldClass(Boolean(errors.date))
										}),
										errors.date ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldError, { message: errors.date }) : null
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-2 gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "block text-sm font-semibold text-ink",
										htmlFor: "base-fee",
										children: ["Fee", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											id: "base-fee",
											inputMode: "numeric",
											value: form.baseFee,
											onChange: (event) => update("baseFee", event.target.value.replace(/[^\d]/g, "")),
											className: fieldClass(Boolean(errors.baseFee))
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "block text-sm font-semibold text-ink",
										htmlFor: "discount",
										children: ["Discount", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											id: "discount",
											inputMode: "numeric",
											value: form.discount,
											onChange: (event) => update("discount", event.target.value.replace(/[^\d]/g, "")),
											className: fieldClass(Boolean(errors.discount))
										})]
									})]
								})
							]
						}),
						errors.baseFee ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldError, { message: errors.baseFee }) : null,
						errors.discount ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldError, { message: errors.discount }) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "submit",
							className: "min-h-12 w-full rounded-md bg-blue text-base font-semibold text-white hover:bg-blue-deep sm:w-auto sm:px-8",
							children: "Book appointment"
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: "h-fit rounded-md border border-line bg-surface p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-semibold tracking-wide text-muted",
							children: "Fee slip"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-3xl font-bold tabular-nums text-ink",
							children: preview === null ? "—" : formatRupees(preview)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted",
							children: preview === null ? "Fee minus discount. Discount cannot pass the consult fee." : discount > 0 ? `${formatRupees(base)} consult, ${formatRupees(discount)} off.` : "No discount on this visit."
						})
					]
				})]
			})
		]
	});
}
function FieldError({ message }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "mt-2 text-sm font-medium text-navy",
		role: "alert",
		children: message
	});
}
function SlipRow({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
		className: "text-xs text-muted",
		children: label
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
		className: "font-semibold text-ink",
		children: value
	})] });
}
function Registry() {
	const appointments = useDesk((state) => state.appointments);
	const [query, setQuery] = (0, import_react.useState)("");
	const trimmed = query.trim();
	const exact = searchPatient(appointments, trimmed);
	const lowered = trimmed.toLowerCase();
	const partial = appointments.filter((appointment) => {
		return appointment.patient.toLowerCase().includes(lowered) || appointment.id.toLowerCase().includes(lowered) || appointment.phone.includes(trimmed.replace(/\s+/g, "")) || appointment.doctor.toLowerCase().includes(lowered) || appointment.department.toLowerCase().includes(lowered);
	});
	const usingExact = exact.length > 0;
	const results = !trimmed ? appointments : usingExact ? exact : partial;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rise",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-3xl font-bold tracking-tight text-ink",
				children: "Registry"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-sm text-muted",
				children: [
					countAppointments(appointments),
					" appointment",
					appointments.length === 1 ? "" : "s",
					" on the books. An exact patient name uses the desk search. Anything else looks through the list."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "mt-5 flex items-center gap-2 rounded-md border border-line bg-surface px-3",
				htmlFor: "patient-search",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
					className: "size-4 shrink-0 text-muted",
					"aria-hidden": "true"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					id: "patient-search",
					value: query,
					onChange: (event) => setQuery(event.target.value),
					placeholder: "Search patient, ID, phone, or doctor",
					className: "min-h-12 w-full bg-transparent text-base text-ink placeholder:text-muted"
				})]
			}),
			trimmed && usingExact ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-3 text-sm font-medium text-leaf",
				children: [
					"Exact name match for “",
					trimmed,
					"”."
				]
			}) : null,
			trimmed && !usingExact && partial.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-muted",
				children: "No exact name match. Showing close results."
			}) : null,
			appointments.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-5 rounded-md border border-dashed border-line bg-surface px-4 py-8 text-sm text-muted",
				children: "No appointments found. Book the first visit from the Book tab."
			}) : results.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-5 rounded-md border border-dashed border-line bg-surface px-4 py-8 text-sm text-muted",
				children: "Patient not found."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-4 space-y-3",
				children: results.map((appointment) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppointmentCard, { appointment }) }, appointment.id))
			})
		]
	});
}
function ChartTip({ active, payload, label }) {
	if (!active || !payload?.length) return null;
	const value = payload[0]?.value ?? 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-md border border-line bg-surface px-3 py-2 text-sm shadow-md",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-semibold text-ink",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "tabular-nums text-muted",
			children: [
				value,
				" appointment",
				value === 1 ? "" : "s"
			]
		})]
	});
}
function Insights() {
	const appointments = useDesk((state) => state.appointments);
	const total = countAppointments(appointments);
	const counts = DEPARTMENTS.map((department) => ({
		name: SHORT_DEPT[department],
		full: department,
		total: appointments.filter((appointment) => appointment.department === department).length
	}));
	const peak = Math.max(...counts.map((row) => row.total));
	const leaders = counts.filter((row) => row.total > 0 && row.total === peak).length;
	const sorted = (0, import_react.useMemo)(() => [...appointments].sort((a, b) => a.patient.localeCompare(b.patient) || a.id.localeCompare(b.id)), [appointments]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rise",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-3xl font-bold tracking-tight text-ink",
				children: "Insights"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-sm text-muted",
				children: ["Total appointments: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-semibold tabular-nums text-ink",
					children: total
				})]
			}),
			total === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-5 rounded-md border border-dashed border-line bg-surface px-4 py-8 text-sm text-muted",
				children: "No appointments yet, so there is nothing to count."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-5 rounded-md border border-line bg-surface p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-base font-bold text-ink",
						children: "Appointments by department"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 h-64 w-full",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
							width: "100%",
							height: "100%",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
								data: counts,
								margin: {
									top: 8,
									right: 4,
									left: -18,
									bottom: 0
								},
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
										dataKey: "name",
										tick: {
											fill: "var(--color-muted)",
											fontSize: 12
										},
										axisLine: false,
										tickLine: false
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
										allowDecimals: false,
										tick: {
											fill: "var(--color-muted)",
											fontSize: 12
										},
										axisLine: false,
										tickLine: false
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
										cursor: { fill: "var(--color-sky)" },
										content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartTip, {})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
										dataKey: "total",
										radius: [
											8,
											8,
											0,
											0
										],
										children: counts.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, { fill: leaders === 1 && row.total === peak ? "var(--color-leaf)" : "var(--color-blue)" }, row.full))
									})
								]
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-2 space-y-1 text-sm text-muted",
						children: counts.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: row.full }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-semibold tabular-nums text-ink",
								children: row.total
							})]
						}, row.full))
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-base font-bold text-ink",
					children: "Sorted by patient name"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 divide-y divide-line overflow-hidden rounded-md border border-line bg-surface",
					children: sorted.map((appointment) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center justify-between gap-3 px-4 py-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "min-w-0 truncate font-medium text-ink",
							children: appointment.patient
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "shrink-0 text-sm font-semibold tabular-nums text-blue",
							children: appointment.id
						})]
					}, appointment.id))
				})]
			})] })
		]
	});
}
var ROLES = [
	"Reception",
	"Consultant",
	"Admin"
];
var PILLAR_ICONS = [
	HeartPulse,
	Users,
	ShieldCheck
];
var PILLAR_LABELS = [
	"Better Care",
	"A Healthier Tomorrow",
	"Trusted Always"
];
function WelcomeGate() {
	const signIn = useDesk((state) => state.signIn);
	const [name, setName] = (0, import_react.useState)("");
	const [role, setRole] = (0, import_react.useState)("Reception");
	const [error, setError] = (0, import_react.useState)("");
	function submit(event) {
		event.preventDefault();
		const trimmed = name.trim().replace(/\s+/g, " ");
		if (trimmed.length < 2) {
			setError("Enter the name on your staff badge.");
			return;
		}
		signIn({
			name: trimmed,
			role
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "relative min-h-dvh",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src: "/media/zoe-medicity-welcome.png",
			alt: "",
			className: "absolute inset-0 h-full w-full object-cover object-top"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "relative z-10 flex min-h-dvh items-end justify-center px-4 py-5 sm:items-center sm:justify-end sm:p-10 lg:p-16",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: submit,
				className: "rise w-full max-w-md rounded-lg border border-white/50 bg-surface/95 p-5 shadow-2xl backdrop-blur-md sm:p-7",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wordmark, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-6 text-3xl font-bold tracking-tight text-ink",
						children: "Welcome back"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: "Sign in to continue to Zoe Medicity Hospital Management System"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mt-4 block h-1 w-14 rounded-full bg-blue" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "mt-6 block text-sm font-semibold text-ink",
						htmlFor: "staff-name",
						children: ["Staff name", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: "staff-name",
							name: "staff-name",
							autoComplete: "name",
							value: name,
							onChange: (event) => {
								setName(event.target.value);
								if (error) setError("");
							},
							placeholder: "e.g. Neha Kapoor",
							className: "mt-2 w-full rounded-md border border-line bg-mist px-3 py-3 text-base font-medium text-ink outline-none placeholder:font-normal placeholder:text-muted focus:border-blue"
						})]
					}),
					error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm font-medium text-navy",
						role: "alert",
						children: error
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
						className: "mt-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
							className: "text-sm font-semibold text-ink",
							children: "Desk role"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2 grid grid-cols-3 gap-2",
							children: ROLES.map((option) => {
								const selected = option === role;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									"aria-pressed": selected,
									onClick: () => setRole(option),
									className: selected ? "min-h-11 rounded-md bg-blue px-2 text-sm font-semibold text-white" : "min-h-11 rounded-md border border-line bg-surface px-2 text-sm font-semibold text-ink",
									children: option
								}, option);
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "submit",
						className: "mt-6 min-h-12 w-full rounded-md bg-blue text-base font-semibold text-white hover:bg-blue-deep",
						children: "Sign in"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-center text-xs text-muted",
						children: "The appointment book stays on this device."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-5 grid grid-cols-3 gap-2 border-t border-line pt-4",
						children: PILLAR_LABELS.map((label, index) => {
							const Icon = PILLAR_ICONS[index];
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "text-center",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
									className: "mx-auto size-5 text-blue",
									"aria-hidden": "true"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-1 block text-xs font-medium leading-tight text-muted",
									children: label
								})]
							}, label);
						})
					})
				]
			})
		})]
	});
}
function useDeskHydrated() {
	const [hydrated, setHydrated] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const persistApi = useDesk.persist;
		if (persistApi.hasHydrated()) {
			setHydrated(true);
			return;
		}
		return persistApi.onFinishHydration(() => setHydrated(true));
	}, []);
	return hydrated;
}
function Home() {
	const hydrated = useDeskHydrated();
	const session = useDesk((state) => state.session);
	if (!hydrated) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WelcomeGate, {});
	if (!session) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WelcomeGate, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Desk, {});
}
//#endregion
export { Home as component };
