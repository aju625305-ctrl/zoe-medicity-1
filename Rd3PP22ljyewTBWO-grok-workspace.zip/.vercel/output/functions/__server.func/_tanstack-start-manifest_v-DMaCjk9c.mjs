//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DMaCjk9c.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-Df3oxHW4.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Df3oxHW4.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BD84C9Bo.js"]
	}
} });
//#endregion
export { tsrStartManifest };
